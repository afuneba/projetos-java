public class OlaMundo {
    // método main inicia a execução do aplicativo Java
    public static void main(String[] args) {
        System.out.println("Bem vindo ");
        System.out.println("ao IOS!");
    } // fim do método main
} // fim da classe OlaMundo


